package com.sg.es.book.tradeservice.controllers;

import com.sg.es.book.tradeservice.TradeRequest;
import com.sg.es.book.tradeservice.TradeResponse;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.Authorization;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.List;

@RestController
@RequestMapping("/trades")
public class TradeServiceController {

	private List<TradeResponse> tradeList = Arrays.asList(
			new TradeResponse(1L, "Success"),
			new TradeResponse(2L, "Failure")
	);


	@RequestMapping(value = "/post-trade",name = "/post-trade",method = RequestMethod.POST,produces = "application/json",consumes = "application/json")
	@ApiOperation(value = "Post trade operation",notes = "API for posting trade related operation", response = TradeResponse[].class,authorizations = {@Authorization(value = "Authorization")})
	public List<TradeResponse> postTrade(@RequestBody TradeRequest tradeRequest) {
		return tradeList;
	}
}
