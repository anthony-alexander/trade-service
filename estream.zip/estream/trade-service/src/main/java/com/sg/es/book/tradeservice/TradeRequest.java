package com.sg.es.book.tradeservice;

/**
 * Created by anthony on 12-11-2017.
 */
public class TradeRequest {

    private Long id;
    private String description;
    private String title;

    public TradeRequest(Long id, String description, String title){
        this.id=id;
        this.description=description;
        this.title=title;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
