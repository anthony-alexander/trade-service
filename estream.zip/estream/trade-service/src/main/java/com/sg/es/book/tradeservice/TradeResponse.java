package com.sg.es.book.tradeservice;

/**
 * Created by anthony on 12-11-2017.
 */
public class TradeResponse {

    private Long id;
    private String responseMessage;

    public TradeResponse(Long id, String message){
        this.id=id;
        this.responseMessage = message;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getResponseMessage() {
        return responseMessage;
    }

    public void setResponseMessage(String responseMessage) {
        this.responseMessage = responseMessage;
    }
}
